# tooth decay > Tooth decay Dataset
https://universe.roboflow.com/new-workspace-jmblq/tooth-decay

Provided by a Roboflow user
License: Public Domain

